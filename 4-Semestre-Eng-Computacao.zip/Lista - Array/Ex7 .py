# Crie um array de números inteiros V[5]. Inicialize esse vetor com números fixos e aleatórios (a sua escolha). Exiba como saída a média dos valores desse vetor.

vet = []

for i in range (10):
  vet.append (int (input ("digite um num ")))
  novo = int (input("Digite um numero"))
  vet.append (novo)
	
soma = 0
for i in range (len(vet)):
  soma = soma + vet [i]

for novo in vet:
  soma = soma + novo

media = soma / len (vet)

print (media)
