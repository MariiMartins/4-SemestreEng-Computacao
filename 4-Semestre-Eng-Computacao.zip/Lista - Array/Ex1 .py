# Crie um array de números inteiros de tamanho 20. Inicialize esse array com números fixo (a sua escolha). Exiba como saída o conteúdo do índice 7 desse array.

teste = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19]

i = 0
for i in range (7):
  valor = teste [i]
  print (valor)