#Faça um algoritmo que leia 20 entradas. Para cada valor lido, coloque em um vetor P ou I, conforme os valores forem pares ou ímpares. O tamanho dos vetores P e I é de 10 posições.

arrayd20 = []
P = []
E = []

for i in range (10):
  arrayd20.append (int (input ("Digite um numero ")))
  novo = int (input("Digite um numero"))
  arrayd20.append (novo)

tamanho = len (arrayd20)
i = 0
for i in range (tamanho):
  if (arrayd20 [i] % 2 == 0 ):
    P.append (arrayd20 [i])
    
  else:
    E.append (arrayd20 [i])

print (P)
print (E)
