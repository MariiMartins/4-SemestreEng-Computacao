# Dada uma matriz de tamanho 6 por 10. Pede-se:
# a) Inicialize essa matriz apenas com 1 (um) e 0 (zero) (números inteiros) aleatoriamente.
# b) Inverta o conteúdo da matriz, ou seja, onde era 1 fica 0 e onde era 0 fica 1.
# Desafio: inicialize a matriz novamente com 1 e zero aleatoriamente... faça um algoritmo que uma vez encontrado o número 1, toda a linha e toda a coluna da posição encontrada passará a ser 1.


M = [[1,0,0,0,1],[0,0,0,0,0],[0,0,0,0,0]] 
linhas = [] 
colunas = [] 

quantidadeLinhas = len(M) 
quantidadeColunas = len(M[0]) 

#varrendo a matriz e procurando o 1
for i in range(quantidadeLinhas): 
  for j in range(quantidadeColunas): 
    if(M[i][j] == 1): 
      linhas.append(i) 
      colunas.append(j) 

#substiuindo as linhas 
for l in range(len(linhas)): 
  for i in range(quantidadeLinhas): 
    if(linhas[l] == i): 
      for j in range(quantidadeColunas): 
        M[i][j] = 1 

#substiuindo as colunas 
for c in range(len(colunas)): 
  for i in range(quantidadeLinhas): 
    for j in range(quantidadeColunas): 
      if(colunas[c] == j): 
        M[i][j] = 1