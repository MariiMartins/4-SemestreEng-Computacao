# Faça um algoritmos que armazene 10 números inteiros informados pelo usuário em um array. Exiba como saída o MENOR numero desse array.

arrayTeste = [0,0,0,0,0,0,0,0,0,0]
menor = arrayTeste[0]
for i in range (5):
  arrayTeste.append (float (input ("digite um numero ")))
  novo = int (input("Digite um numero"))
  arrayTeste.append (novo)

tamanho = len (arrayTeste)

i = 0
for i in range (tamanho):
  valor =  arrayTeste [i]
  
  if (arrayTeste[i] < menor):
    menor = valor
print (menor)
