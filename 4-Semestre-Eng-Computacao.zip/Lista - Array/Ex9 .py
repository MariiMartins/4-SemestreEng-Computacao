# Foi realizada uma pesquisa entre os habitantes de uma dada região. Foram recolhidos os dados de idade e salário. Construa um algoritmo que informe:
#a) a média de salário do grupo;
#b) a média de idade
#c) maior e menor idade do grupo;
#d) maior e menor salário do grupo
# Encerre a entrada de dados quando for digitada uma idade negativa  OBRIGATÓRIO ARMAZENAMENTO DAS IDADES e SALÁRIOS EM ARRAYS

habitantes = int(input("Digite o numero de habitantes = "))
Sal = [0,0]
Idade = [0,0]
soma = 0 
somaIdade = 0
maiorS = Sal[0]
menorS = Sal[0]
maiorI = Idade[0]
menorI = Idade[0]

for i in range (habitantes):
  sal = int(input("Digite o salário = "))
  if(Sal[i] <= maiorS):
    maiorS = sal
  if(Sal[i] >= menorS):
    menorS = sal
  Sal.append(sal)

for i in range (len(Sal)):
  soma = soma + Sal[i]
tamanho = len(Sal)
media = soma/tamanho
print("A media de salário foi = ",media)
print ("O maior salário = ",maiorS,"\n O menor salário = ",menorS)

for j in range (habitantes):
  idade = int(input("Digite as idades = "))
  if(Idade[j] <= maiorI):
    maiorI = idade
  if(Idade[j] >= menorI):
    menorI = idade
  Idade.append(idade)

for j in range (len(Idade)):
  somaId = somaIdade + Idade[j]
tamanho2 = len(Idade)
mediaS = somaId/tamanho2

print("A media de idade é = " ,mediaS)
print ("A maior idade = ",maiorI, "\n A menor idade = ",menorI)
