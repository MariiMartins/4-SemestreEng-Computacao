# Faça um algoritmos que armazene 10 números inteiros informados pelo usuário em um array. Exiba como saída o MAIOR numero desse array. OBRIGATÓRIO O USO DE LAÇO DE REPETIÇÃO PARA LEITURA DO ARRAY.

arrayTeste = [0,0,0,0,0,0,0,0,0,0]
maior = arrayTeste[0]
for i in range (5):
  arrayTeste.append (float (input ("digite um numero ")))
  novo = int (input("Digite um numero"))
  arrayTeste.append (novo)
	
tamanho = len (arrayTeste)

i = 0
for i in range (tamanho):
  valor =  arrayTeste [i]
  
  if (arrayTeste[i] > maior):
    maior = valor
print (maior)
