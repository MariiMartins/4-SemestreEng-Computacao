# Crie um array de tamanho 10 nos quais serão armazenados os valores das notas de laboratório. Alimente esse array com entradas do usuário.
# Exiba como saída a média dos valores desse vetor e exiba também, como saída, quanto o laboratório representará na sua média final (lembrando que Média Final = (Lab * 0,1) + (PMI * 0,1) + (PAP * 0,2) + (P1 * 0,3) + (P2 * 0,3)) OBRIGATÓRIO O USO DE LAÇO DE REPETIÇÃO PARA ARMAZENAMENTO E LEITURA DO ARRAY.

lab = []

for i in range (5):
  lab.append (float (input ("digite o valor da atv ")))
  novo = float (input("Digite valor da atv"))
  lab.append (novo)

soma = 0
for i in range (len(lab)):
  soma = soma + lab [i]

for novo in lab:
  soma = soma + novo

media = soma / len (lab)

print ("a média dos valores é " +str (media))

leb = media * 0.1
print ("representará em sua prova " (leb))

