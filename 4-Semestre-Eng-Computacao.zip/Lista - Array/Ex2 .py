# Crie um array de números inteiros de tamanho 5. Alimente esse array com entradas fornecidas pelo usuário. Exiba como saída o conteúdo do índice 3 desse array.

l = [1] * 5
for i in range (5):
  l[i] = int(input ("Digite um numero "))
print (l[2])

#
arrayTeste = []

x = int (input("Digite um numero "))

w = int (input("Digite um numero "))

a = int (input("Digite um numero "))

c = int (input("Digite um numero "))

e = int (input("Digite um numero "))

arrayTeste.insert(0,x)
arrayTeste.insert(1,w)
arrayTeste.insert(2,a)
arrayTeste.insert(3,c)
arrayTeste.insert(4,e)

tamanho = len (arrayTeste)

i = 0
for i in range (3):
  valor =  arrayTeste [i]
  print (valor)
  
#
arrayTeste = [0,1,2,3,4]

x = int (input("Digite um numero "))
y = int (input("Digite uma posição "))
arrayTeste.insert(y,x)

tamanho = len (arrayTeste)

i = 3
for i in range (3):
  valor =  arrayTeste [i]
  print (valor)

