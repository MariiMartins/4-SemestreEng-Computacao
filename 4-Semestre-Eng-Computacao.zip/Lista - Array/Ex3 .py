# Faça um algoritmo que leia 2 vetores A[10] e B[10]. A seguir, Crie um vetor C que seja a intersecção de A com B e mostre este vetor C. Obs.: Intersecção é quando um valor estiver nos dois vetores. Considere que não há elementos duplicados em cada um dos vetores.

a = [3,5,7,9,1,11,19,15,17,13,0]
b = [2,4,6,8,0,10,18,16,14,12]
c = []

for i in range (len(a)):
  for j in range (len(b)):
    if a[i] == b[j]:
      c.append (a[i])

print (c)      