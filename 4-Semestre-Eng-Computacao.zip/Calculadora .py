num1 = input ("Digite um numero ")
num2 = input ("Digite outro numero ")

soma = float (num1) + float (num2)
sub = float (num1) - float (num2)
multi = float (num1) * float (num2)
div = float (num1) / float (num2)
porc = float (num1) % float (num2)
exp = float (num1) ** float (num2)

print (soma , sub, multi, div, porc, exp)
