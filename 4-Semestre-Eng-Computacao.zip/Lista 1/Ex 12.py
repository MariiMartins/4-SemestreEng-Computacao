# Leia um número de entrada e exiba seu sucessor.
numero = int(input("Entre com o número"))
numero += 1
print(numero)