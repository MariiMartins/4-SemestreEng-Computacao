# Realize e exiba a soma de dois números ponto flutuante do tipo FLOAT (Obs: pode utilizar dois números fixos)

numero1 = 7.25
numero2 = 3.8
resultado = numero1 + numero2
print (resultado)