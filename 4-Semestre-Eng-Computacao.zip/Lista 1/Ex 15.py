# (DESAFIO) Leia o valor de duas entradas A e B e exiba o valor invertido dessas entradas

a = int(input("Etre com o valor de A"))
b = int(input("Etre com o valor de B"))
aux = a
a = b
b = aux
print(a)
print(b)
