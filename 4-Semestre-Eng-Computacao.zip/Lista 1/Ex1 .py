# Realize e exiba a soma de dois números inteiros 
#(Obs: pode utilizar dois números fixos)

numero1 = 20
numero2 = 30
resultado = numero1 + numero2
print(resultado)
