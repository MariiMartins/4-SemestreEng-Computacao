# Sabe-se que o professor Fabio (por incrível que pareça) gosta de corridas de rua. Costuma(va) correr provas de 5 Km, 10 Km, 16 Km e até 21 Km. Sabe-se que o professor costuma (ou costumava) correr a uma média de 10,5 Km/h. Dada uma distância (como as citada acima), exiba o tempo médio que o professor usará para completar a prova

distancia = int(input("Entre com a distância"))
#convertendo a distancia para metros
distancia = distancia * 1000
#convertendo a velocidade para metros por segundo
velocidade = 10.5 / 3.6
#calcula tempo total em segundos
tempoTotalSegundos = int(distancia / velocidade)
print(tempoTotalSegundos)
#convertendo...
horas = tempoTotalSegundos // 3600
minutos = (tempoTotalSegundos % 3600) // 60
segundos = (tempoTotalSegundos % 3600) % 60
print(horas, ":", minutos, ":", segundos)
