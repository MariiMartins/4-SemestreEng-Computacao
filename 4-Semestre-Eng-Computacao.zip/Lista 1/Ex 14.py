# Imagine o seguinte problema fictício:
# A nota final de laboratório é calculada pela média das notas N1, N2 e N3.
# Resolva esse problema, sendo que as notas serão entradas informadas pelo usuário.

n1 = float(input("Entre com a N1"))
n2 = float(input("Entre com a N2"))
n2 = float(input("Entre com a N2"))
notaFinal = (n1 + n2 + n3) / 3
print("Sua nota final é:", notaFinal)