# Realize e exiba o resto da divisão de dois números inteiros (Obs: pode utilizar dois números fixos)

numero1 = 7
numero2 = 3
resultado = numero1 % numero2
print(resultado)