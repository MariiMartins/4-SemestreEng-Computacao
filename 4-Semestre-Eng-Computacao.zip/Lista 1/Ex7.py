# Realize e exiba a subtração de dois números ponto flutuante do tipo FLOAT (Obs: pode utilizar dois números fixos)

numero1 = 8.66
numero2 = 3.8
resultado = numero1 - numero2
print(resultado)