# Desenvolva um algoritmo que receba como entrada do usuário um número inteiro e devolva como saída esse mesmo número subtraído de 3.

numero = int(input("Entre com o número"))
numero -= 3
print(numero)