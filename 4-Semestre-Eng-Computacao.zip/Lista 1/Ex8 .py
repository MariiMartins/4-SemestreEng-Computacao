# Desenvolva um algoritmo que receba como entrada do usuário um número inteiro e devolva como saída esse mesmo número acrescido de 2.

numero = int(input("Entre com o número"))
numero = numero + 2
print(numero)