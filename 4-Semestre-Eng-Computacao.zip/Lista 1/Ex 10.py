#Desen volva um algoritmo que receba como entrada do usuário um número inteiro e devolva como saída esse mesmo número divido por 3 e multiplicado por 10.

numero = int(input("Entre com o número"))
resultado = (numero / 3 ) * 10
print(numero)