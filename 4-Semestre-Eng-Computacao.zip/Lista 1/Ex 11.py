# Desenvolva um algoritmo que receba como entrada do usuário um número inteiro e devolva como saída esse mesmo número multiplicado por 6 e dividido por 8.

numero = int(input("Entre com o número"))
resultado = (numero * 6 ) / 8
print(numero)