# Realize e exiba a multiplicação de dois números inteiros (Obs: pode utilizar dois números fixos)

numero1 = 7
numero2 = 4
resultado = numero1 * numero2
print(resultado)