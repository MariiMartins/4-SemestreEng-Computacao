# Realize e exiba a divisão de dois números inteiros (Obs: pode utilizar dois números fixos)

numero1 = 4
numero2 = 2
resultado = numero1 / numero2
print(resultado)