# Um colega de trabalho lhe apresentou o algoritmo em Python abaixo que tem como objetivo somar todos os números de um vetor e exibir o resultado dessa soma na tela. Pergunta-se: existe algum erro nesse algoritmo? Se sim, indique a correção.

V = [10, 20, 30, 40, 50, 60] 
soma = 0 
i = 0 
for i in range(5):
  soma += V[i] 
print(soma)      

#	o algoritmo le apenas até o 5º numero do vetor.