# Dado os algoritmos em Python abaixo, considerando as entradas A=4, B=2, C=1 e D=10

I- 
if not(D > 5): 
X=(A+B)*D 
else: 
X=(A-B)//D

II
if(A > B and B < 7): 
X=(A+2)*(B-2) 
else: 
X=(A+B)//D*(C+D)

III
if((A >= 2) or (C <= 1)): 
X=(A+D)//2 
else: 
X = D * C
 
É correto o que se afirma como saída de I, II e III respectivamente, em:
a) 60, 6, 10 respectivamente
b) 60, 0 e 7 respectivamente
c) 0.2, 0 e 7 respectivamente
d) 0.2, 5 e 7 respectivamente
e) 0, 0 e 7 respectivamente    <-
