#Faça um algoritmo que leia um vetor V de tamanho 6 (você pode inicializar o vetor com valores fixos se preferir, mas não é obrigatório). Conte a seguir, quantos valores de V são negativos e mostre essa informação.

arrayd6 = [1, 2, 3, -1, -2, -3]
neg = []
tamanho = len (arrayd6)
i = 0
for i in range (tamanho):
  if (arrayd6[i] < 0):
     neg.append (arrayd6 [i])

high = len (neg)
print (neg)
print (high)
