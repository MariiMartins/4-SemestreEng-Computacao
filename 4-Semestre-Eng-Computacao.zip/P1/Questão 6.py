# Dado o algoritmo abaixo, complete a lógica dando como saída se o aluno foi ou não aprovado (REGRA: o aluno é aprovado somente se a sua nota final for maior ou igual a 7.0, caso contrário ele é reprovado) A nota final é a média da soma das 3 provas.

prova1 = float(input("Entre com o primeiro número"))
prova2 = float(input("Entre com o número"))
prova3 = float(input("Entre com o número"))

media = (prova1 + prova2 + prova3)

medfin = (media / 3)

if (media < 7):
  print ("Não foi aprovado")
  else:
    print (" Aprovado!")
