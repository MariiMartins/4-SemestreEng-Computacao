# Faça um algoritmo que leia um vetor V de 10 posições (você pode inicializar o vetor com valores fixos se preferir, mas não é obrigatório) e coloque os números ímpares em um vetor denominado I e os pares em um vetor denominado P

vetor = []
P = []
I = []

for i in range (5):
  vetor.append (int (input ("Digite um numero ")))
  novo = int (input("Digite um numero"))
  vetor.append (novo)

tamanho = len (vetor)
i = 0
for i in range (tamanho):
  if (vetor [i] % 2 == 0 ):
    P.append (vetor [i])
    
  else:
    I.append (vetor [i])

print (P)
print (I)
