#Um determinado algoritmo possui duas entradas: dois números inteiros e três saídas, na forma de mensagem impressa para o usuário na tela: - a soma dos dois números; - mensagem indicando qual número é o menor; - mensagem indicando se o produto é par ou impar. Complete o algoritmo abaixo:

primeiroNumero = int(input("Entre com o primeiro número"))
segundoNumero = int (input("Entre com o segundo número"))

soma = (primeiroNumero + segundoNumero)
print (soma)

prod = (primeiroNumero * segundoNumero)

if (prod % 2 == 0 ):
  print ("é Par")
else:
  print ("é impar ")
    
if (primeiroNumero < segundoNumero):
  print (primeiroNumero)
else:
  print (segundoNumero)

