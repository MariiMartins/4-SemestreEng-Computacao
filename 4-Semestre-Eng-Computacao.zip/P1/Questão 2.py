#Complete o algoritmo em Python abaixo que tem como objetivo exibir os números ímpares de 0 (zero) até o número informado pelo usuário

numero = int(input("Entre com o primeiro número"))

cont = 0

while (cont < numero):
  if (cont % 2 == 1 ):
    print (cont)
  cont = cont + 1 
