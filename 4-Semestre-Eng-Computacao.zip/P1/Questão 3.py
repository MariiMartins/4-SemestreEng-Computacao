#Complete o algoritmo em Python abaixo que tem como objetivo exibir os números múltiplos de 3 (três) de 0 até o número informado pelo usuário

numero = int(input("Entre com o primeiro número"))
cont = 0

while (cont < numero):
  if (cont % 3 == 0 ):
    print (cont)
  cont = cont + 1 
