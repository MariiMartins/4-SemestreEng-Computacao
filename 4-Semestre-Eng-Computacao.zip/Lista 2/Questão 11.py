#Considere as medidas dos lados de um triangulo: A, B e C. Faça um algoritmo que indique se o triangulo é equilátero (três lados iguais) isósceles (dois iguais e um diferente) ou escaleno (três lados diferentes entre si).

## Pré-condição: identificar se as três medidas formam um triangulo: cada um dos lados é menor do que a soma dos outros dois, caso um dos lados seja menor então as medidas não podem formar um triângulo. 

ladoA = int(input("Entre com lado A")) 
ladoB = int(input("Entre com lado B")) 
ladoC = int(input("Entre com lado C"))

if( (ladoA > ladoB + ladoC) or (ladoB > ladoA + ladoC) or (ladoC > ladoA + ladoB) ): 
  print("não é um triangulo") 
else: 
  if( (ladoA == ladoB) and (ladoB == ladoC) and (ladoC == ladoA)): 
    print("equilatero") 
  elif( (ladoA != ladoB) and (ladoB != ladoC) and (ladoC != ladoA)): 
    print("escaleno") 
  else: 
    print("isosceles")