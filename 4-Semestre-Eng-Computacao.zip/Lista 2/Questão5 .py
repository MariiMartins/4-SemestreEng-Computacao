# Um fabricante de roupas esportivas pretende colocar nas embalagens de seus produtos o valor sugerido como preço de venda ao consumidor final. Esse preço sugerido deve ser definido de tal maneira que o varejista possa reduzi-lo em até 20% e ainda assim obter um lucro de 15% sobre o preço de custo (o preço de custo é o valor que o varejista paga pelo produto ao fabricante). Conhecendo-se o preço de custo de um dos produtos como obter o valor do preço de venda sugerido? 

precoCusto = float(input("entre com o valor")) 
precoVenda = (precoCusto * 1.15) / 0.8 
print(precoVenda)