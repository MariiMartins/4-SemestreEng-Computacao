# Faça um algoritmo que receba o ano atual, o ano de casamento e escreva as seguintes mensagens:
# • 25 anos – “Bodas de prata”
# • 50 anos – “Bodas de ouro”
# • 75 anos – “Bodas de Diamante”
# • Nos casos restantes apenas escrever o número de anos de casados

anoAtual = int(input("Entre com o ano atual")) 
anoCasamento = int(input("Entre com o ano casamento")) 
diferenca = anoAtual - anoCasamento 
if(diferenca == 75): 
  print("Bodas diamante") 
elif(diferenca == 50): 
  print("Bodas de ouro") 
elif(diferenca == 25): 
  print("Bodas de prata") 
else: 
  print(diferenca)