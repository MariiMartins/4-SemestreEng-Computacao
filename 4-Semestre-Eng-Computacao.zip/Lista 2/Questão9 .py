# Dado a entrada de dois números inteiros, exiba para o usuário qual número é o maior.

numero1 = int(input("Entre com o número 1")) 
numero2 = int(input("Entre com o número 2")) 
if(numero1 > numero2): 
  print(numero1) 
else: 
  print(numero2)