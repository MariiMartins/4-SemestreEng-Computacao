# Dado a entrada de um número, exiba para o usuário se esse número é par ou ímpar

numero1 = int(input("Entre com o número 1")) 
resto = numero1 % 2 
if(resto == 0): 
  print("numero par") 
else: 
  print("numero impar")