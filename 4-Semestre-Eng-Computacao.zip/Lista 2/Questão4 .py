# A bilheteria de uma estação de metro possui moedas de 1 centavo, 10 centavos, 50 centavos e 1 real para compor os valores de troco. Conhecendo-se o valor a ser cobrado (em reais) e o valor fornecido por um usuário (também em reais), como determinar as quantidades de cada tipo de moeda, necessárias para completar o valor do troco, de maneira que seja utilizado o menor número de moedas no total? 

valorFornecido = float(input("entre com o valor fornecido")) 
valorCobrado = float(input("entre com o valor cobrado"))
 
troco = valorFornecido - valorCobrado 
trocoCentavos = troco * 100 
qtdMoedasUm = trocoCentavos // 100 
resto = trocoCentavos % 100
qtdMoedas25 = resto // 25 
resto = resto % 25 
qtdMoedas10 = resto // 10 
resto = resto % 10 
qtdMoedas5 = resto // 5 
print("Moedas de $1 = "+ str (qtdMoedasUm))
print("Moedas de $.25 = " +str (qtdMoedas25)) 
print("Moedas de $.10 = " +str (qtdMoedas10)) 
print("Moedas de $.05 = " +str (qtdMoedas5))