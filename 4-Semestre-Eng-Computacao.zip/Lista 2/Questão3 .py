# Um reservatório vazio deve ser abastecido por uma bomba. Conhecendo-se a vazão da bomba (em litros por segundo), a capacidade do reservatório (em litros). Calcule o tempo que levará para encher o reservatório em: segundos, minutos e horas (quantidades inteiras) 

vazao = int(input("Entre com a vazao")) 

capacidadeReservatorio = int(input("Entre com a capacidade")) 

tempoTotalSegundos = capacidadeReservatorio / vazao

horas = tempoTotalSegundos // 3600 

minutos = (tempoTotalSegundos % 3600) // 60 

segundos = (tempoTotalSegundos % 3600) % 60 

print(horas, ":", minutos, ":", segundos)