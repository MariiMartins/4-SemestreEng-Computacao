# A nota final de um aluno é calculada pela média da nota de 3 provas que valem de 0 (zero) a 10 (dez). O aluno será aprovado se obter média superior a 7. Desenvolva um algoritmo que exiba apenas se o aluno foi aprovado ou não.

n1 = float(input("entre com n1")) 
n2 = float(input("entre com n2")) 
n3 = float(input("entre com n3")) 
media = (n1 + n2 + n3) / 3 
if(media >= 7): 
  print("Aprovado") 
else:
  print("Não Aprovado")