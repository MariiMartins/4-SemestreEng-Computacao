#Faça um algoritmo que receba o preço de custo de um produto e mostre o valor de venda. Sabe-se que o preço de custo receberá um acréscimo de acordo com um percentual informado pelo usuário.

precoCusto = float(input("Entre com preço de custo")) percentual = float(input("Entre com percentual")) precoFinal = precoCusto + (precoCusto * (percentual / 100)) print(precoFinal)