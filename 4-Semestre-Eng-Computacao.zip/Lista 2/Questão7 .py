# A nota final de um aluno é calculada pela média da nota de 3 provas que valem de 0 (zero) a 10 (dez). O aluno será aprovado se obter média superior a 7, todavia se o aluno obter média inferior a 7 e maior que 4 ele poderá fazer um exame final. Desenvolva um algoritmo que exiba para o aluno todas as suas possibilidades.

n1 = float(input("entre com n1")) 
n2 = float(input("entre com n2")) 
n3 = float(input("entre com n3")) 
media = (n1 + n2 + n3) / 3 
if(media >= 4 and media < 7): 
  print("Exame") 
elif(media >= 7): 
    print("Aprovado") 
else: 
      print("Não Aprovado")