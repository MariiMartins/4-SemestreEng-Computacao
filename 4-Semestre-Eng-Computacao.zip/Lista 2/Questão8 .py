# Desenvolva um algoritmo que faça a leitura de três números inteiros, representado uma data (dd,mm,aaaa) e imprima a data por extenso. Exemplo: 31 3 2012; saída: 31 de março de 2012. 

dd = int(input("Entre com o dia")) 
mm = int(input("Entre com o mes")) 
aaaa = int(input("Entre com o ano")) 
mes = "" 
if(mm == 1): 
  mes = "janeiro" 
elif(mm == 2):
  mes = "fevereiro" 
elif(mm == 3): 
  mes = "março" 
elif(mm == 4): 
  mes = "abril" 
elif(mm == 5): 
  mes = "maio" 
elif(mm == 6): 
  mes = "junho" 
elif(mm == 7): 
  mes = "julho" 
elif(mm == 8): 
  mes = "agosto" 
elif(mm == 9): 
  mes = "setembro" 
elif(mm == 10): 
  mes = "outubro" 
elif(mm == 11): 
  mes = "novembro" 
elif(mm == 12): 
  mes = "dezembro" 

data = str(dd) + " de " + mes + " de " + str(aaaa) 
print(data)