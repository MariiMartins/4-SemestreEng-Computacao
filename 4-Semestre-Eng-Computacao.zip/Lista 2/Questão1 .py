# Faça um algoritmo que converta e exiba o resultado em real (R$) de um valor em dólar (US$). Solicitar o valor da cotação do dólar para o usuário

valor = float(input("Entre com o montante em US$")) 
cotacao = float(input("Entre com a cotação"))

convertido = valor * cotacao 
print(convertido)