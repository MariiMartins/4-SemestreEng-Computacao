a = int (input ("Digite um numero INTEIRO: "))
b = int (input ("Digite outro numero INTEIRO: "))
sub = int (a - b)
print (sub)
