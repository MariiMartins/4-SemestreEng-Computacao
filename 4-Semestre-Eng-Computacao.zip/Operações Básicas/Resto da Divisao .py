a = int (input ("Digite um numero INTEIRO: "))
b = int (input ("Digite outro numero INTEIRO: "))
resto = int (a % b)
print (resto)
