a = float (input ("Digite um numero INTEIRO: "))
b = float (input ("Digite outro numero INTEIRO: "))
subfl = float (a - b)
print (subfl)
