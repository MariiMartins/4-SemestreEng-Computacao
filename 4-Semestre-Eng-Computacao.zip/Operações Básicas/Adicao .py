a = int (input ("Digite um numero INTEIRO: "))
b = int (input ("Digite outro numero INTEIRO: "))
soma = int (a + b)
print (soma)
