a = int (input ("Digite um numero INTEIRO: "))

somadois = int (a + 2)
print (somadois)
