a = int (input ("Digite um numero INTEIRO: "))
b = int (input ("Digite outro numero INTEIRO: "))
divi = int (a / b)
print (divi)
