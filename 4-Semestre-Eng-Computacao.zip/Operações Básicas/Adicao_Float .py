a = float (input ("Digite um numero INTEIRO: "))
b = float (input ("Digite outro numero INTEIRO: "))
somfl = float (a + b)
print (somfl)
