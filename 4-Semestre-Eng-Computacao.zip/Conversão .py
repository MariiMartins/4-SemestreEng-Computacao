fare = input("Digite um valor em Fareheint ")
celsius = (float (fare) - 32) / 1.8
	
print("O valor em Celsius é " + str (celsius))

#
celsius = input("Digite um valor em Celsius ")
fare = (float (celsius) * 1.8) + 32

print("O valor em Fareheint é " +str(fare))

#
kmh = input ("Digite um valor de Quilometragem ")
ms = float  (kmh) / 3.6

print ("O valor é " +str (ms) + "M/S")

#
met = input ("Digite um valor em Metros ")
rkmh = float (met) * 3.6
print ("O valor é "+str (rkmh) + "KM/H")
