#Desenvolver um algoritmo que exiba os números pares de 1 a 400.

n_pares = 2
while (n_pares < 402):
    print(n_pares)
    n_pares += 2

