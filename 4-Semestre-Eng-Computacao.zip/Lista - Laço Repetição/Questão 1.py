# Desenvolver um algoritmo que exiba os números ímpares de 1 ate 100.

for i in range (1, 100, 2):

  print(i)

#
n_imp = 1
while (n_imp < 100):
    print(n_imp)
    n_imp += 2
