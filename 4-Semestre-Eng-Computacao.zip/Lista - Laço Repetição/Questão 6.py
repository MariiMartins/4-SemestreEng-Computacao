# Ler um número maior que 0 e imprimir a soma de todos os números menores que o número lido.

num = int(input("Digite um numero maior que 0: "))
count = 0

for i in range(0, num):
    count += i

print (count)
