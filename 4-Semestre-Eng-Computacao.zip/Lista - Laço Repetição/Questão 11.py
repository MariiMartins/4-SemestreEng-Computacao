# Obter o máximo divisor comum de dois valores inteiros

a = int(input("Digite um valor maior que zero "))
b = int(input("Digite outro valor maior que zero "))
mdc = a
while a % mdc != 0 or b % mdc != 0: 
  mdc = mdc - 1

print("O MDC entre %d,%d (%d)" %(a,b,mdc))

