# Ler um número inteiro e imprimir todos os números primos de 1 até o número informado.

num = int (input ("Digite um numero"))

for i in range (1,num+1):
  ePrimo = True

  for j in range (2, i):
    if i%j == 0:
      ePrimo = False
  if ePrimo:
    print (i)
