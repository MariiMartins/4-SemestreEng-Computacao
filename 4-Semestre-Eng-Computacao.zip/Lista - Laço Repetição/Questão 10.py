# Obtenha o espelho de um valor inteiro positivo.

num = str(input("Digite um numero: "))

k = len(num)
num = int(num)
novo_num = 0

while num != 0:
  novo_num += (num % 10) * 10**(k-1)
  num //= 10
  k -= 1

print (novo_num)
