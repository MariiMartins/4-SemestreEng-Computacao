# Ler dois numeros e imprimir todos os numeros entre eles. Suponha que o segundo numero seja maior que o primeiro.

n1 = int (input("Digite o numero 1"))
n2 = int (input ("Digite o numero 2"))

for i in range (n1,n2):   
  print (i)
