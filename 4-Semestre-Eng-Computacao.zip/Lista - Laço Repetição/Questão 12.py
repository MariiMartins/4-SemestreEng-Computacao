# Foi realizada uma pesquisa entre os hanitantes de uma dada região. Foram recolhidos os dados de idade, sexo e salario. Construa um algoritmo que informe:
# Media Salario; maior e menor idade; qnt mulheres salraio até 500

idade = 0 
sexo = "F" 
salario = 0.0 
qtdeMulheresSalario = 0 
somaSalario = 0 
contador = 0 
mediaSalarial = 0.0 
menorIdade = 999 
maiorIdade = 0 
while(1==1): 
  sexo = input("Entre com o sexo") 
  idade = int(input("Entre com a idade")) 
  salario = float(input("Entre com o salario")) 
#sai do loop se idade negativa 
  if(idade < 0): 
    break

  if(sexo == "F" and salario < 500): 
    qtdeMulheresSalario += 1 

  somaSalario = somaSalario + salario 

  if(idade < menorIdade): 
    menorIdade = idade 

  if(idade > maiorIdade): 
    maiorIdade = idade 

  contador += 1 

if(contador > 0): 
  mediaSalarial = somaSalario / contador 
  print(mediaSalarial) 

print(qtdeMulheresSalario)

print(menorIdade) 

print(maiorIdade)