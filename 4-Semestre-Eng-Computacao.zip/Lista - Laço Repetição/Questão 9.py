# Desenvolver um algoritmo que exiba o resultado do fatorial de um número inteiro informado pelo usuário.

num = int (input("Digite um número: "))
fat = 1

for i in range (1, num+1):
  fat *= i
print (fat)
