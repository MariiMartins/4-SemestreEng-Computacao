# Ler um número maior que zero e imprimir o quadrado de todos os números entre 0 e o número lido.

a = int (input ("Digite um numero maior que zero "))
n = 0
while (n <= a):
  print(n**2)
  n += 1
