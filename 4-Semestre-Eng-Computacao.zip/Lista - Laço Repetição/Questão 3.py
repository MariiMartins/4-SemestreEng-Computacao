# Imprimir  o quadrado dos números de 1 até 20

n = 0
while (n < 20):
  print(n**2)
  n += 1
