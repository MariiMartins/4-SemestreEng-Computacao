# Imprimir os multiplos de 5, no intervalo de 1 até 500.

for multi in range (5,505,5):
  print (multi)
